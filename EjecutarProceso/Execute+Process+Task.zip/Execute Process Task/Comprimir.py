import gzip

input = open("C:/SQL Server Integration Services/Execute Process Task/Reporte Cliente.txt",'rb')
s=input.read()
input.close()

output = gzip.GzipFile("C:/SQL Server Integration Services/Execute Process Task/Comprimido/Reporte Cliente.txt.gz",'wb')
output.write(s)
output.close()

print("Done")