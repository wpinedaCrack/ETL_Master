﻿$Ruta = "C:\SQL Server Integration Services\Execute Process Task\"
$Archivo = "Reporte Cliente.txt"

$Ruta+$Archivo

if( Test-Path($Ruta+$Archivo) )
{
    Remove-Item($Ruta+$Archivo)
}


